static struct CMD_XDRCommandInfo ${ns.replace('::','_',400)}_Commands[] = {

static struct CMD_ErrorInfo ${ns.replace('::','_',400)}_Errors[] = {

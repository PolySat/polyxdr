   XDR_register_struct(&${st.name.replace('::','_',400)}_Struct);

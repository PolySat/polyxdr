static void ${namespace.upper()}_structs_constructor()
    __attribute__((constructor));

static void ${namespace.upper()}_structs_constructor()
{

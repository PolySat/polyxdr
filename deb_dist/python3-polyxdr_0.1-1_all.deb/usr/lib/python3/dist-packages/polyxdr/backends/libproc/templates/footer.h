extern void ${namespace.upper().replace('::','_',400)}_forcelink(void);

#ifdef __cplusplus
}
#endif

#endif

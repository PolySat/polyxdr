#define ${const.name.replace('::','_',400)} (${const.value})


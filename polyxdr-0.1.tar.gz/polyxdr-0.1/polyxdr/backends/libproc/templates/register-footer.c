   CMD_register_commands(${namespace.replace('::','_',400)}_Commands, ${repl});
   CMD_register_errors(${namespace.replace('::','_',400)}_Errors);
}

# polyxdr
A parser and code generator for PolySat's custom XDR-based data definition language.

## Install
`sudo python3 setup.py install`

## Usage
```
usage: poly-xdrgen [-h] --target {python,xp,libproc,telem-dict}
                   [--output PATH]
                   FILE
poly-xdrgen: error: the following arguments are required: FILE, --target/-t
```
